# Vercel Web Voting System
## Deploy
1. Create a Supabase project.
2. Open SQL Editor and run `supabase.sql`.
3. Push this folder to GitHub.
4. Import the repository into Vercel.
5. Add environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `ADMIN_USERNAME`
   - `ADMIN_PASSWORD`
6. Deploy.
7. Open `/admin`.
8. Create a poll and share `/poll/POLL_ID`.

IMPORTANT: Keep `SUPABASE_SERVICE_ROLE_KEY` secret. Do not prefix it with NEXT_PUBLIC_.
The voter-token method prevents repeat voting from the same browser cookie. For high-stakes elections, use authenticated/verified voter identities.
